package com.example.lenovo.widget2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ImageView i1;
    TextView t1,t2,t3,t4;
    RadioButton r1,r2;
    CheckBox c1;
    Switch s1;
    SeekBar see;
    ToggleButton tb;
    RelativeLayout r;
    RadioGroup rg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        r1=(RadioButton)findViewById(R.id.radioButton);
        r2=(RadioButton)findViewById(R.id.radioButton2);
        tb=(ToggleButton)findViewById(R.id.toggleButton);
        c1=(CheckBox)findViewById(R.id.checkBox);
        t1=(TextView)findViewById(R.id.textView);
        t2=(TextView)findViewById(R.id.textView2);
        t3=(TextView)findViewById(R.id.textView3);
        t4=(TextView)findViewById(R.id.textView4);
        s1=(Switch)findViewById(R.id.switch1);
        see=(SeekBar)findViewById(R.id.seekBar2);
        r=(RelativeLayout) findViewById(R.id.rl);
        i1=(ImageView)findViewById(R.id.imageView);
        rg=(RadioGroup) findViewById(R.id.rg);
        RadioButton CheckedRadioButton=(RadioButton)rg.findViewById(rg.getCheckedRadioButtonId());
             /*   RelativeLayout r=(RelativeLayout)findViewById(R.id.rl);
                r.setBackgroundResource(R.drawable.psk);
                int pic= R.drawable.psk;
                r.setBackgroundResource(pic);*/
             tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                 @Override
                 public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                     if(isChecked)
                     {
                         r.setBackgroundResource(R.drawable.psk);
                         t2.setText("night mode off");
                     }
                     else
                     {
                         r.setBackgroundResource(android.R.drawable.btn_default);
                         t2.setText("night mode on");
                     }
                 }
             });
             c1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                 @Override
                 public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                     if(isChecked)
                     {
                         t3.setText(" checkbox selected");
                     }
                     else
                     {
                         t3.setText("checkbox not selected");

                     }
                 }
             });
           /*  rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                 @Override
                 public void onCheckedChanged(RadioGroup radioGroup, int i) {
                     RadioButton radioButton = (RadioButton) radioGroup.findViewById(i);
                     if (radioButton.isChecked())
                     {
                         t1.setText(radioButton.getText());
                     }
                 }
             });*/
           rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
               @Override
               public void onCheckedChanged(RadioGroup radioGroup, int i) {
                   int id=rg.getCheckedRadioButtonId();
                   switch(id)
                   {
                       case R.id.radioButton:t1.setText("male");
                       break;
                       case R.id.radioButton2:t1.setText("female");
                           break;
                   }
               }
           });

           see.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
               @Override
               public void onProgressChanged(SeekBar seekBar, int i, boolean fromUser) {
                    t4.setTextSize(i);
                  //  Toast.makeText(getApplicationContext(),String.valueOf(i),Toast.LENGTH_LONG).show();
               }

               @Override
               public void onStartTrackingTouch(SeekBar seekBar) {

               }

               @Override
               public void onStopTrackingTouch(SeekBar seekBar) {

               }
           });
         s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
             @Override
             public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                 i1 = (ImageView) findViewById(R.id.imageView);
                 Animation startRotateAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                 if (b) {

                     i1.startAnimation(startRotateAnimation);
                 }
                else
                 {
                     i1.clearAnimation();
                 }

             }
         });
    }
}
