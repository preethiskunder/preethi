package com.example.lenovo.simplecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;
    EditText edit1,edit2;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.add);
        b2=(Button)findViewById(R.id.sub);
        b3=(Button)findViewById(R.id.div);
        b4=(Button)findViewById(R.id.mul);
        edit1=(EditText)findViewById(R.id.edit1);
        edit2=(EditText)findViewById(R.id.edit2);
        text=(TextView)findViewById(R.id.text);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                int c=a+b;
                text.setText(Integer.toString(c));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                int c=a-b;
                text.setText(Integer.toString(c));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                try{
                int c=a/b;
                text.setText(Integer.toString(c));
                }
                catch(Exception e)
                {
                    Toast.makeText(MainActivity.this,"cant devide", Toast.LENGTH_LONG).show();


                }
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                int c=a*b;
                text.setText(Integer.toString(c));
            }
        });
    }

}


