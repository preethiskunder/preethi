package com.example.lenovo.sorting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.app.ProgressDialog.show;

public class MainActivity extends AppCompatActivity {
    Button b1;
    EditText e1;
    TextView t1;
    int[] str;
    String num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button);
        e1 = (EditText) findViewById(R.id.editText);
        t1 = (TextView) findViewById(R.id.textView);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] a = e1.getText().toString().split(",");

               str = new int[a.length];
                for (int i = 0; i < a.length; i++) {
                    str[i] = Integer.parseInt(a[i]);
                }
               sort(str, 0, str.length - 1);
               for (int i=0; i < a.length ; i++)
               {

                   t1.setText(t1.getText().toString()+Integer.toString(str[i])+" ");//not to overright

               }
               // t1.setText(num);
            }
        });
    }


    int partition(int[] str, int low, int high) {
        int i, j, temp;
        int p;
        p = str[low];
        i = low + 1;
        j = high;
        while (low < high) {
            while (str[i] <= p && i < high)
                i++;
            while (str[j] > p)
                j--;
            if (i < j) {
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
            } else {
                temp = str[low];
                str[low] = str[j];
                str[j] = temp;
                return j;
            }
        }
         return j;
    }
    void sort(int[]str, int low, int high) {
        if (low < high) {
            int pos = partition(str, low, high);
            sort(str, low, pos - 1);
            sort(str, pos + 1, high);
        }
    }
}
